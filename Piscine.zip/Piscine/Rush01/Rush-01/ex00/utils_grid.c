/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_grid.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zfarah <zfarah@student.hive.fi>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 14:40:42 by zfarah            #+#    #+#             */
/*   Updated: 2025/01/26 19:31:47 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>

char	*make_arr(int elements);
void	fill_clues_by_count(char **grid, char *clue, int count);
void	fill_left_col_clues(char **grid, char *clues);
void	fill_right_col_clues(char **grid, char *clues);
void	fill_top_row_clues(char **grid, char *clues);
void	fill_bottom_row_clues(char **grid, char *clues);

char	**grid_initialize(int rows, int cols)
{
	int i;
 	int j;
	char **grid = (char**) malloc(rows * sizeof(char*));
	i = 0;
	while(i < cols)
	{
		grid[i] = (char*) malloc((cols + 1) * sizeof(char));
		j = 0;
		while (j < cols)
		{
			grid[i][j] = ' ';
			j++;
		}
		grid[i][j] = '\0';
		i++;
	}
	return grid;
}

void	fill_grid_with_clues(char **grid, char *clues);

void	fill_grid_with_clues(char **grid, char *clues)
{
	char *current_clue = make_arr(4); // initialize 4 e
	int count;
	int i;

	count = 0;
	i = 0;	
	while(*clues)
	{
		if(*clues == ' ')
		{
			clues++;
			continue;
		}
		current_clue[i] = *clues;
		if (i == 3)
		{
			printf("clue-%d  %s \n",count, current_clue);
			fill_clues_by_count(grid, current_clue, count);
			i = -1;
			count++;
		}
		i++;
		clues++;
	}
}

void	fill_clues_by_count(char **grid, char *clues, int count)
{
	if (count == 0) // top row
	{
		fill_top_row_clues(grid, clues);	
	}
	else if (count == 1) // bottom row
	{
		fill_bottom_row_clues(grid, clues);	
	} 
	else if (count == 2) // left col?
	{
		fill_left_col_clues(grid, clues);
	}
	else if (count == 3) { // right col?
		fill_right_col_clues(grid, clues);
	}
}

void	fill_left_col_clues(char **grid, char *clues)
{
	int	i;
	int j;

	i = 1;
	j = 0;
	while( i < 5)
	{
		grid[i][0] = clues[j];
		j++;
		i++;
	}
}

void	fill_right_col_clues(char **grid, char *clues)
{
	int	i;
	int j;

	i = 1;
	j = 0;
	while( i < 5)
	{
		grid[i][5] = clues[j];
		j++;
		i++;
	}
}

char	*get_row_clues(char **grid, int row)
{
	char *clues = make_arr(2);
	clues[0] = grid[row][0];
	clues[1] = grid[row][5];
	return clues;
}

char	*get_col_clues(char **grid, int col)
{ // not sure if this works 100% test it after bottom, and top clues are available
	char *clues = make_arr(2);
	clues[0] = grid[0][col];
	clues[1] = grid[5][col];
	return clues;
}