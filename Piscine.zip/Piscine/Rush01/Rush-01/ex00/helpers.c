/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helpers.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zfarah <zfarah@student.hive.fi>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 18:07:16 by zfarah            #+#    #+#             */
/*   Updated: 2025/01/26 16:18:45 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>

void	print_grid(char **grid);
char	*get_row_clues(char **grid, int row);
char	*get_col_clues(char **grid, int col);

void	print_grid(char **grid)
{
    int	i;
    i = 0;
    while (i < 6) 
    {
        printf ("-%s-\n", grid[i]);
	i++;
    }
}

void	fill_top_row_clues(char **grid, char *clues)
{
	int	i;
	
	i = 1;
	while (i < 5)
	{
		grid[0][i] = clues[i-1];
		i++;
	}
	print_grid(grid);
}

void	fill_bottom_row_clues(char **grid, char *clues)
{
	int i;
	
	i = 1;
	while (i < 5)
	{
		grid[5][i] = clues[i-1];
		i++;
	}
	print_grid(grid);
}

char	*make_arr(int elements)
{
	char	*arr = (char*) malloc((elements + 1) * sizeof(char));
	int		i;

	i = 0;
	while (i < elements)
	{
		arr[i] = ' ';
		i++;
	}
	arr[i] = '\0';
	return (arr);
}

int		inputs_valid(char **grid)
{
	int i = 1;
	int j = 1;
	char *clues;
	//char **pointer;
	
	while (i < 5)
	{
		int row;
		clues = get_row_clues(grid, row);
		int i;
		
		
		if((clues[0] + clues[1]) > 5)
		{
			return(0);
		}
		i++;
	}
	i = 1;

	while (j < 5)
	{
		 while (j < 5)
		{
			int col;
			clues = get_col_clues(grid, col);
			clues[1];
			int j;
			
			if((clues[0] + clues[1]) > 5)
			{
				return(0);
			}
			j++;
		}
	}
	return(1);
}






 