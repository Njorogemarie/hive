/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zfarah <zfarah@student.hive.fi>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 13:29:13 by zfarah            #+#    #+#             */
/*   Updated: 2025/01/25 18:32:24 by zfarah           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int		inputs_valid(char **grid);
void	fill_grid_with_clues(char **grid, char *clues);
char	*get_row_clues(char **grid, int row); // helper funcion to get row clues
char    **grid_initialize(int rows, int cols);
void	print_grid(char **grid);
char	*get_row_clues(char **grid, int row);

int main(int argsc, char **args)
{
	// initialize grid
	char **grid = grid_initialize(6, 6);
	print_grid(grid);

	// fill grid with clues
	fill_grid_with_clues(grid, args[1]);
	print_grid(grid);
	
	if (!inputs_valid(grid))
	{
		write(1, "Error", 5);
		return(0);
	}
	// printf("%s", get_row_clues(grid, 2));
	// store the clues and begin with empty g


	// check if solvable, valid set
	
	



	// try solving the rest, recursive?


}
