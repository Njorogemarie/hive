/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge.mnjoroge@student.h      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/17 09:58:11 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/18 16:36:54 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_numbers(void)
{
	int	number;

	number = 1;
	while (number >= '9')
	{
		write(1, &number, 1);
		number++;
	}
}

int main(void)
{
  ft_print_numbers();
  return 0;
}	
