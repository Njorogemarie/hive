/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/23 16:09:01 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/24 10:55:46 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	while (*src != '\0')
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (dest);
}
/*int main() {
    char src[] = "Hello, World!";
    char dest[20] = "";  

    printf("Before copy:\n");
    printf("Source: %s\n", src);
    printf("Destination: %s\n", dest);

    // Copy and print the result
    ft_strcpy(dest, src);
    printf("\nAfter copy:\n");
    printf("Source: %s\n", src);
    printf("Destination: %s\n", dest);

    return 0;
}*/
