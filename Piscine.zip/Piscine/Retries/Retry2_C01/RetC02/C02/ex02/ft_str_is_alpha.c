/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/26 10:49:37 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/26 11:13:15 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str);

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 'A' && str[i] <= 'Z') 
			|| (str[i] >= 'a' && str[i] <= 'z')))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*int main()
{
    printf("%d\n", ft_str_is_alpha("Hello"));  
    printf("%d\n", ft_str_is_alpha("Hello123"));  
    printf("%d\n", ft_str_is_alpha("12345"));  
    printf("%d\n", ft_str_is_alpha(""));  
    return 0;
}*/
