/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/29 19:56:26 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/29 20:29:26 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str)
{
	int	sign;
	int	result;

	sign = 1;
	result = 0;
	while (*str == ' ' || *str == '\t' || *str == '\n')
	{
		str++;
	}
	while (*str == '-' || *str == '+' )
	{
		if (*str == '-')
		{
			sign = -sign;
		}
		str++;
	}	
	while (*str >= '0' && *str <= '9')
	{
		result = result * 10 + (*str - '0');
		str++;
	}
	return (result * sign);
}
/*int main() {
    const char *str = " ---+--+1234ab567";
    int num = ft_atoi((char*)str);
    printf("The converted integer is %d\n", num); 
    return 0;
}*/
