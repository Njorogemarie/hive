/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/29 09:32:27 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/29 09:56:07 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strstr(char *str, char *to_find);

char	*ft_strstr(char *str, char *to_find)
{
	char	*start;
	char	*temp_to_find;

	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{	
		start = str;
		temp_to_find = to_find;
		while (*temp_to_find != '\0' && *temp_to_find == *start)
		{
			temp_to_find++;
			start++;
		}
		if (*temp_to_find == '\0')
		{
			return (str);
		}
		str++;
	}
	return (0);
}
/*int main()
{
    char arr1[] = "abcdefsrysky";
    char arr2[] = "sky";
    printf("%s", ft_strstr(arr1, arr2));
    return 0; 
}*/	
