/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/29 17:19:28 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/29 17:25:32 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void    ft_putnbr(int nb)
{
    unsigned int	num;
    
    if (nb < 0)
    {
        write(1, "-", 1);
        num = -nb;
    }
    else
    {
        num = nb;
    }
    
    if (num >= 10)
    {
        ft_putnbr(num / 10);
    } 
    num = num % 10 + '0';
    write (1, &num, 1);
}

int main ()
{
	int n3 = -2147483648;
    	ft_putnbr(n3); 
    	write(1, "\n", 1);
    	
    	int n4 = 2147483647;
    	ft_putnbr(n4); 
    	write(1, "\n", 1);
    	
    	int n5 = 0;
    	ft_putnbr(n5); 
    	write(1, "\n", 1);
}
