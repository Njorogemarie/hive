/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/24 11:06:53 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/26 22:27:41 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strncpy(char *dest, char *src, unsigned int n);

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{		
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}	

int main() {
    char dest[20]; 
    const char *src = "Hello, world!";

  
    ft_strncpy(dest, src, 5);
    printf("Result (n=5): %s\n", dest);  // Should print "Hello"

    // Test with n larger than the length of the source string
    ft_strncpy(dest, src, 20);
    printf("Result (n=20): %s\n", dest);  // Should print "Hello, world!" and pad with '\0'

    // Test with n exactly equal to the length of the source string
    ft_strncpy(dest, src, 13);
    printf("Result (n=13): %s\n", dest);  // Should print "Hello, world!"

    return 0;
}
