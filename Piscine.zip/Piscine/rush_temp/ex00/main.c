/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnjoroge <mnjoroge.mnjoroge@student.h      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/18 16:01:10 by mnjoroge          #+#    #+#             */
/*   Updated: 2025/01/18 17:31:38 by mnjoroge         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void rush(int x, int y)
{
	int y_place;
	int x_place;
	
	y_place = 1;
	while(y_place <= y)
	{
		x_place = 1;
		while (x_place <= x)
		{
			ft_putchar('A');
			x_place++;
		}
		write(1, "\n", 1);
		y_place++;
	}
}

int	main(void)
{
	rush(5,5);
	return 0;
}
	
