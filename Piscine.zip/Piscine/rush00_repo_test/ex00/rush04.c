/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cdohanic <cdohanic@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/19 13:55:42 by cdohanic          #+#    #+#             */
/*   Updated: 2025/01/19 13:56:35 by cdohanic         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_if(int j, int x, int middle)
{
	if (middle == 1)
	{
		if (j == 1 || j == x)
			ft_putchar('B');
		else
			ft_putchar(' ');
	}
	else if (middle == 0)
	{
		if (j == 1)
			ft_putchar('A');
		else if (j == x)
			ft_putchar('C');
		else
			ft_putchar('B');
	}
	else
	{
		if (j == 1)
			ft_putchar('C');
		else if (j == x)
			ft_putchar('A');
		else
			ft_putchar('B');
	}
}

void	rush(int x, int y)
{
	int	i;
	int	j;

	i = 1;
	while (i <= y)
	{
		j = 1;
		while (j <= x)
		{
			if (i == 1)
				ft_if(j, x, 0);
			else if (i == y)
				ft_if(j, x, 2);
			else
				ft_if(j, x, 1);
			j++;
		}
		i++;
		ft_putchar('\n');
	}
}
