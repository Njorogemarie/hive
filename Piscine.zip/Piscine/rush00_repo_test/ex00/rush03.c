/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cdohanic <cdohanic@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/18 11:37:01 by cdohanic          #+#    #+#             */
/*   Updated: 2025/01/19 13:11:03 by cdohanic         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_if(int j, int x, int middle)
{
	if (middle == 0)
	{
		if (j == 1)
			ft_putchar('A');
		else if (j == x)
			ft_putchar('C');
		else
			ft_putchar('B');
	}
	else
	{
		if (j == 1 || j == x)
			ft_putchar('B');
		else
			ft_putchar(' ');
	}
}

void	rush(int x, int y)
{
	int	i;
	int	j;

	i = 1;
	while (i <= y)
	{
		j = 1;
		while (j <= x)
		{
			if (i == y || i == 1)
				ft_if(j, x, 0);
			else
				ft_if(j, x, 1);
			j++;
		}
		i++;
		ft_putchar('\n');
	}
}
